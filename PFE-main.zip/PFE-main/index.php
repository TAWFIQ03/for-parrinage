<?php require_once('connect.php'); ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="index.css" />
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>
    <!-- new -->



    <!-- <?php
            // if (isset($_POST['submit'])) {
            //     $req = "SELECT * FROM client WHERE Email='" . $_POST['user'] . "' AND password='" . $_POST['upass'] . "'";
            //     if ($resultat = mysqli_query($mybstock, $req)) {
            //         $ligne = mysqli_fetch_assoc($resultat);
            //         if ($ligne != 0) {
            //             session_start();
            //             $_SESSION['user'] = $_POST['user'];
            //             header("location:client.php");
            //         }
            //     } else {
            //         header("history.go()");
            //     }
            // }

            ?> -->

    <!-- new -->
    <div class="container">
        <div class="frame">
            <div class="nav">
                <ul class="links">
                    <li class="signin-active"><a class="btn">Sign in</a></li>
                    <li class="signup-inactive"><a class="btn">Sign up </a></li>
                </ul>
            </div>
            <div >
                <form class="form-signin" action="" method="post" name="form">
                    <label for="username">Email</label>
                    <input class="form-styling" type="text" name="email" placeholder="" />
                    <label for="password">Password</label>
                    <input class="form-styling" type="password" name="passwoord" placeholder="" />
                    <input type="checkbox" id="checkbox" />
                    <label for="checkbox"><span class="ui"></span>Keep me signed in</label>
                    <div class="btn-animate"> <a name="btlogin" class="btn-signin">Sign in</a>
                    </div>
                </form>
                <form class="form-signup" action="" method="post" name="form">
                    <label for="fullname">First name</label>
                    <input class="form-styling" type="text" name="fullname" placeholder="" />
                    <label for="fullname">Last name</label>
                    <input class="form-styling" type="text" name="fullname" placeholder="" />
                    <label for="email">Email</label>
                    <input class="form-styling" type="text" name="emai" placeholder="" />
                    <label for="password">Password</label>
                    <input class="form-styling" type="text" name="password" placeholder="" />
                    <label for="confirmpassword">Confirm password</label>
                    <input class="form-styling" type="text" name="confirmpassword" placeholder="" />
                    <label for="fullname">Address</label>
                    <input class="form-styling" type="text" name="fullname" placeholder="" />
                    <label for="fullname">Phone</label>
                    <input class="form-styling" type="text" name="fullname" placeholder="" />
                    <label for="fullname">City</label>
                    <input class="form-styling" type="text" name="fullname" placeholder="" />
                    <label for="fullname">Region</label>
                    <input class="form-styling" type="text" name="fullname" placeholder="" />

                    <a ng-click="checked = !checked" class="btn-signup">Sign Up</a>
                    <?php
                    if (isset($_POST['btlogin'])) {
                        $req = "select * from admin where Email='". $_POST['email'] . "'and Passw='" . $_POST['passwoord'] . "'";
                        if ($resultat = mysqli_query($mybd, $req)) {
                            $ligne = mysqli_fetch_assoc($resultat);
                            if ($ligne != 0) {
                                session_start();
                                $_SESSION['email'] = $_POST['email'];
                                header("location:admin.php");
                            } else {
                                echo "<font color='red'>login ou mot de passe est invalide</font>";
                            }
                        }
                    }
                    ?>
                </form>

            </div>





            <script src="./index.js"></script>


</body>

</html>