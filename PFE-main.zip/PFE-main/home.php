<?php
require_once 'connect.php';
if (isset($_GET['deleteproduct'])) {
  $delete = $_GET['deleteproduct'];
  $reqDelete = "DELETE FROM catigories WHERE id='$delete'";
  $resultat = mysqli_query($mybstock, $reqDelete);
  if ($resultat) {
    echo "<label style='text-align: center; color:#964906;'>la supprission a validé";
  } else {
    echo "<label style='text-align: center; color:#964906;'>la supprission a échouée";
  }
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>home</title>
  <link rel="stylesheet" href="stylehome.css">
  <link rel="stylesheet" href="  https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <link href="/your-path-to-fontawesome/css/fontawesome.css" rel="stylesheet">
  <link href="/your-path-to-fontawesome/css/brands.css" rel="stylesheet">
  <link href="/your-path-to-fontawesome/css/solid.css" rel="stylesheet">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.bundle.min.js">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js">
  <link href="  https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/boxicons@latest/css/boxicons.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js">
  <style>
    .hull {
      border: 5px;
      background-color: black;
      padding: 10px;
    }



    .jumbotmro {
      z-index: -1000;
    }
  </style>
</head>

<body id="body-pd">
  <!-- <div id="container">
<form name="formdelet" class="formulaire">

<p><a href="index.php" class="btn btn-primary btn-md mr-1">logout</a></p> -->
  <?php
  // $reqselect="SELECT * from catigories order by catigorie desc";
  // $resultat=mysqli_query($mybstock,$reqselect);

  // $nbr=mysqli_num_rows($resultat);
  // echo "<p> Total <b> ".$nbr."</b> Produits</p>";
  ?>
  <!-- </div> -->





  <header class="header bg-dark" id="header">
    <div class="header_toggle " style="color:#fabd03;"> <i class='bx bx-menu' id="header-toggle"></i> </div>
    <div class=" d-flex pt-4 justify-content-center"> <a href="#" class="nav_logo">
        <img width="100vw" height="50vh" src="./myimgs/logocoi.png" alt=""></a>
    </div>
    <a href="#" class="nav_link">
            <i class='bx bx-user nav_icon'></i> <span class="nav_name">Users</span> </a>
    <!-- <div class="header_img"> <i class='bx bx-user nav_icon'></i> </div> -->
  </header>
  <div class="l-navbar" id="nav-bar">
    <nav class="nav">
      <div>
        <div class="nav_list"> <a href="#" class="nav_link active"> <i class='bx bx-home nav_icon'></i>
            <span class="nav_name">Home</span> </a> <a href="client.php" class="nav_link">
            <i class='bx bx-user nav_icon'></i> <span class="nav_name">Users</span> </a>
          <a href="#" class="nav_link"> <i class='bx bx-message-square-detail nav_icon'></i>
            <span class="nav_name">About</span> </a> <a href="#" class="nav_link">
            <i class='bx bx-bookmark nav_icon'></i> <span class="nav_name">Service</span> </a>
          <a href="contact.php" class="nav_link"> <i class='fa fa-paper-plane nav_icon'></i>
            <span class="nav_name">Contact</span> </a> <a href="client.php" class="nav_link">
            <i class='bx bx-log-in nav_icon'></i> <span class="nav_name">Sign Up</span> </a>
        </div>
      </div> <a href="logout.php" class="nav_link"> <i class='bx bx-log-out nav_icon'></i>
        <span class="nav_name">LogOut</span> </a>
    </nav>
  </div><br><br><br>
  <br><br><br>

  <!-- Home -->

  <div class=" justify-content-center">

    <div class="  mt-4
    ml-5 ">
      <div class="row ">
        <div class="col-lg-6 ">

          <div class="  bg-white ">
            <h1 class="display-4 text-dark  font-weight-bold">Hi,
              Communicate
              with <span class="text-warning"><strong> ATMOSP'</strong></span><span class="text-DARK">HAIR</span><span class="text-warning">.</span></h1>
            <br>
            <br>
            <h5>A <span class="text-warning"><strong> Place</strong></span> Where You Will<span class="text-warning"><strong> Find</strong> </span> Yourself And Your Style<span class="text-warning"><strong>.</strong></span></h5>
            <hr id="X" class="my-4 bg-warning">
            <br><br><br><br>


            <a href="login.php"> <button class="btn btnfrel ml-5 btn-warning botton font-weight-bold ">Get Started</button></a>
<!-- moddel -->

<!-- end moddel -->
          </div>
        </div>
        <!-- carousel -->
        <div class="col-lg-6  jumbotmro ">
          <div class="backr ">


          </div>
        </div>

      </div>
    </div>

    <!-- kkk -->
    <div class=" container">
      <div class="row ">
        <div class="col-12">
          <h1>About The Company</h1>
        </div>

      </div>
      <div class="row ">
        <div class="col-12">
          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolores modi vel blanditiis doloribus commodi impedit!. Lorem ipsum dolor sit amet consectetur adipisicing elit. </p>
        </div>

      </div>
      <div class="row ml-5 ">
        <div class="col-6">
          <div class="card">
            <div class="card_img"> <i class="fas fa-rocket"></i> </div>
            <div class="card_title">HTML</div>
            <div class="card_body">
              <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit.</p>
            </div>
          </div>
        </div>
        <div class="col-6">
          <div class="card">
            <div class="card_img"> <i class="fab fa-cloudversify"></i> </div>
            <div class="card_title">CSS</div>
            <div class="card_body">
              <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit.</p>
            </div>
          </div>

        </div>

      </div>
      <div class="row  ">
        <div class="col-6">
          <div class="card">
            <div class="card_img"> <i class="fas fa-user-astronaut"></i> </div>
            <div class="card_title">JAVASCRIPT</div>
            <div class="card_body">
              <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit.</p>
            </div>
          </div>
        </div>

      </div>


    </div>





    <!-- our team -->

    <br>
    <br>
    <br><br>
    <br>
    <br>

    <div id="container">
      <div id="heading">
        <h1>OUR TEAM</h1>
      </div>
      <div class="item">
        <div class="front"> <img id="team1" class="team" src="https://www.supercuts.com/content/dam/supercuts/www/models/2017-models/1x1/heroes/supercuts-spencer-hero-hairstyles-classic-fade-1x1.png/_jcr_content/renditions/cq5dam.web.320.320.medium.png"> </div>
        <div class="back">
          <p class="title">Tom Crow</p>
          <p class="job">Interface Designer</p> <a href="#"><i class="fab fa-facebook-square social fa-2x"></i></a> <a href="#"><i class="fab fa-linkedin social fa-2x"></i></a> <a href="#"><i class="fab fa-twitter-square social fa-2x"></i></a>
        </div>
      </div>
      <div class="item">
        <div class="front"> <img id="team2" class="team" src="https://www.eikonphoto.com/wp-content/uploads/2017/03/male-headshot-tie-color-e1515795186596.jpg"> </div>
        <div class="back">
          <p class="title">Tom Crow</p>
          <p class="job">Interface Designer</p> <a href="#"><i class="fab fa-facebook-square social fa-2x"></i></a> <a href="#"><i class="fab fa-linkedin social fa-2x"></i></a> <a href="#"><i class="fab fa-twitter-square social fa-2x"></i></a>
        </div>
      </div>
      <div class="item">
        <div class="front"> <img id="team3" class="team" src="https://www.ellasophiephoto.com/IMAGES/portraits/Portrait-Photographer-EllaSophie-OaklandStudio.jpg"> </div>
        <div class="back">
          <p class="title">Tom Crow</p>
          <p class="job">Interface Designer</p> <a href="#"><i class="fab fa-facebook-square social fa-2x"></i></a> <a href="#"><i class="fab fa-linkedin social fa-2x"></i></a> <a href="#"><i class="fab fa-twitter-square social fa-2x"></i></a>
        </div>
      </div>
      <div class="item">
        <div class="front"> <img id="team4" class="team" src="https://static1.squarespace.com/static/51047986e4b0f96ff4ffc8e0/t/58efb3ba5016e1685c551ae7/1492104152438/Mens-Accessories-Tie-Bow-pocket-square"> </div>
        <div class="back">
          <p class="title">Tom Crow</p>
          <p class="job">Interface Designer</p> <a href="#"><i class="fab fa-facebook-square social fa-2x"></i></a> <a href="#"><i class="fab fa-linkedin social fa-2x"></i></a> <a href="#"><i class="fab fa-twitter-square social fa-2x"></i></a>
        </div>
      </div>
      <div class="item">
        <div class="front"> <img id="team5" class="team" src="https://i.pinimg.com/originals/98/c8/0d/98c80de7cee9782322fdca55409bf6bc.jpg"> </div>
        <div class="back">
          <p class="title">Tom Crow</p>
          <p class="job">Interface Designer</p> <a href="#"><i class="fab fa-facebook-square social fa-2x"></i></a> <a href="#"><i class="fab fa-linkedin social fa-2x"></i></a> <a href="#"><i class="fab fa-twitter-square social fa-2x"></i></a>
        </div>
      </div>
      <div class="item">
        <div class="front"> <img id="team6" class="team" src="https://i.pinimg.com/originals/85/1e/7a/851e7a776927d4302e637ae511a3e372.jpg"> </div>
        <div class="back">
          <p class="title">Tom Crow</p>
          <p class="job">Interface Designer</p> <a href="#"><i class="fab fa-facebook-square social fa-2x"></i></a> <a href="#"><i class="fab fa-linkedin social fa-2x"></i></a> <a href="#"><i class="fab fa-twitter-square social fa-2x"></i></a>
        </div>
      </div>
    </div>


    <br>
    <br>
    <br>
    <br>
    <br>
    <br>

    <!-- our service -->


    <div class="container">

      <div class="row ml-4 ">
        <div class="text-center ">
          <h1>Our Services</h1>
        </div>
        <div class="col-md-4">
          <div class="box">
            <div class="our-services settings">
              <div class="icon"> <img src="https://i.imgur.com/6NKPrhO.png"> </div>
              <h4>Settings</h4>
              <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit</p>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="box">
            <div class="our-services speedup">
              <div class="icon"> <img src="https://i.imgur.com/KMbnpFF.png"> </div>
              <h4>Speedup</h4>
              <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit</p>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="box">
            <div class="our-services privacy">
              <div class="icon"> <img src="https://i.imgur.com/AgyneKA.png"> </div>
              <h4>Privacy</h4>
              <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit </p>
            </div>
          </div>
        </div>
      </div>

      <div class="row  ml-4 ">
        <div class="col-md-4">
          <div class="box">
            <div class="our-services backups">
              <div class="icon"> <img src="https://i.imgur.com/vdH9LKi.png"> </div>
              <h4>Backups</h4>
              <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit </p>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="box">
            <div class="our-services ssl">
              <div class="icon"> <img src="https://i.imgur.com/v6OnUqu.png"> </div>
              <h4>SSL secured</h4>
              <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit</p>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="box">
            <div class="our-services database">
              <div class="icon"> <img src="https://i.imgur.com/VzjZw9M.png"> </div>
              <h4>Database</h4>
              <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit</p>
            </div>
          </div>

        </div>
      </div>
    </div>
    <br>
    <br>
    <br>
    <br>



    <!-- our cleint -->
    <div>

      <h1>cleint say</h1>
      <div class="wrapper">


        <div class="carousel slide" id="mySlider" data-ride="carousel" data-interval="4000" data-pause="hover">
          <ol class="carousel-indicators">
            <li data-target="#mySlider" data-slide-to="0" class="active"></li>
            <li data-target="#mySlider" data-slide-to="1"></li>
            <li data-target="#mySlider" data-slide-to="2"></li>
          </ol>
          <div class="carousel-inner text-white">
            <div class="carousel-item active">
              <div class="content">
                <div class="employee">
                  <div class="h3 text-uppercase">James Maddison</div>
                  <div class="h6 text-mute">Customer</div>
                </div>
                <div class="testimonial bg-white text-dark"> <span class="fas fa-quote-left"></span>
                  <div class="text-justify">Lorem ipsum dolor sit amet consectetur adipisicing elit. Quidem error iusto aliquid laboriosam voluptas enim sint expedita architecto in voluptates!</div> <span class="fas fa-quote-right"></span>
                </div>
              </div>
            </div>
            <div class="carousel-item">
              <div class="content">
                <div class="employee">
                  <div class="h3 text-uppercase">Jack Anderson</div>
                  <div class="h6 text-mute">Director</div>
                </div>
                <div class="testimonial bg-white text-dark"> <span class="fas fa-quote-left"></span>
                  <div class="text-justify">Lorem ipsum dolor sit amet consectetur adipisicing elit. Quidem error iusto aliquid laboriosam voluptas enim sint expedita architecto in voluptates!</div> <span class="fas fa-quote-right"></span>
                </div>
              </div>
            </div>
            <div class="carousel-item">
              <div class="content">
                <div class="employee">
                  <div class="h3 text-uppercase">William Wendy</div>
                  <div class="h6 text-mute">Supervisor</div>
                </div>
                <div class="testimonial bg-white text-dark"> <span class="fas fa-quote-left"></span>
                  <div class="text-justify">Lorem ipsum dolor sit amet consectetur adipisicing elit. Quidem error iusto aliquid laboriosam voluptas enim sint expedita architecto in voluptates!</div> <span class="fas fa-quote-right"></span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  </div>
  </div>




  <footer class=" bg-dark justify-content-center ">

    <div class="row">
      <div class="line mb-3 mx-auto"></div>
      <div class="d-md-flex px-5 justify-content-around bd-highlight col-md-12 pt-5 pb-5 mb-3">
        <div class="p-2 flex-fill bd-highlight mb-5 mb-md-0">
          <h3>itCraft</h3> <small>Copyright &copy 2019</small>
        </div>
        <div class="p-2 flex-fill bd-highlight mb-3 mb-md-0">
          <h5 class="places">BYDGOCZCZ</h5>
          <p class="mb-0">Bydgoszcz Centrum Burnesa</p>
          <p class="mb-0">ul Pzzenmdcwa 25, ibsura 24,</p>
          <p class="mb-0">B5-7GB Bydgosrdz, Poland</p>
        </div>
        <div class="p-2 flex-fill bd-highlight mb-3 mb-md-0">
          <h5 class="places">TORUN</h5>
          <p class="mb-0">ul Reyana 2-4</p>
          <p class="mb-0">A0-100 Torun,</p>
          <p class="mb-0">Poland</p>
        </div>
        <div class="p-2 flex-fill bd-highlight mb-3 mb-md-0">
          <h5 class="places">WARSAW</h5>
          <p class="mb-0">Brain Embassy</p>
          <p class="mb-0">Alaya Jerasublisuble RS123</p>
          <p class="mb-0">02-222 Warsawa</p>
        </div>
        <div class="p-2 flex-fill bd-highlight mb-3 mb-md-0">
          <h5 class="places">LONDON</h5>
          <p class="mb-0">Google Campus</p>
          <p class="mb-0">4-5 Barnhill, Shaneditch</p>
          <p class="mb-0">London EC2A 4BK</p>
        </div>
        <div class="p-2 flex-fill bd-highlight mb-3 mb-md-0">
          <h5 class="places">NORWAY</h5>
          <p class="mb-0">Kristiansand</p>
        </div>
      </div>
      <div class="line mb-3 mx-auto"></div>
    </div>
    <div class="row bottom-part">
      <div class="d-lg-flex justify-content-between bd-highlight col-md-12 mb-5 px-5">
        <div class="p-2 align-self-center flex-fill bd-highlight">
          <div class="fa fa-facebook px-2"></div>
          <div class="fa fa-linkedin px-2"></div>
          <div class="fa fa-twitter px-2"></div>
          <div class="fa fa-instagram px-2"></div>
        </div>
        <div class="p-2 row flex-fill bd-highlight justify-content-left">
          <div class="p-2 d-lg-flex">
            <div class="p-2 flex-fill d-flex bd-highlight">Services</div>
            <div class="p-2 flex-fill d-flex bd-highlight">Portfolio</div>
            <div class="p-2 flex-fill d-flex bd-highlight">Pricing</div>
            <div class="p-2 flex-fill d-flex bd-highlight">Testimonials</div>
            <div class="p-2 flex-fill d-flex bd-highlight">Team</div>

            <div class="p-2 flex-fill d-flex bd-highlight">Carrer</div>
            <div class="p-2 flex-fill d-flex bd-highlight">How we work</div>
            <div class="p-2 flex-fill d-flex bd-highlight">Manifesto</div>
          </div>
        </div>
        <div class="p-2 align-self-center flex-fill bd-highlight">
          <div class="fa fa-mobile px-2 grey-text">&nbsp;&nbsp;<span id="contact">888-777-666</span></div>
          <div class="fa fa-envelope-o px-2 grey-text">&nbsp;&nbsp;info@itcraft.in</div>
        </div>
      </div>
    </div>

  </footer>




  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="./style.js"></script>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js"></script>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.0.3/css/font-awesome.css"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  <!-- navbar -->
  <script>
    document.addEventListener("DOMContentLoaded", function(event) {

      const showNavbar = (toggleId, navId, bodyId, headerId) => {
        const toggle = document.getElementById(toggleId),
          nav = document.getElementById(navId),
          bodypd = document.getElementById(bodyId),
          headerpd = document.getElementById(headerId)

        // Validate that all variables exist
        if (toggle && nav && bodypd && headerpd) {
          toggle.addEventListener('click', () => {
            // show navbar
            nav.classList.toggle('show')
            // change icon
            toggle.classList.toggle('bx-x')
            // add padding to body
            bodypd.classList.toggle('body-pd')
            // add padding to header
            headerpd.classList.toggle('body-pd')
          })
        }
      }

      showNavbar('header-toggle', 'nav-bar', 'body-pd', 'header')

      /*===== LINK ACTIVE =====*/
      const linkColor = document.querySelectorAll('.nav_link')

      function colorLink() {
        if (linkColor) {
          linkColor.forEach(l => l.classList.remove('active'))
          this.classList.add('active')
        }
      }
      linkColor.forEach(l => l.addEventListener('click', colorLink))

      // Your code to run since DOM is loaded and ready
    });
  </script>


</body>

</html>