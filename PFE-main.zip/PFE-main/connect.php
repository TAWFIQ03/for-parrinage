<?php
$serveur="localhost";
$user="root";
$pw="";
$bdd="mycoiffeur";

$mybd= new mysqli($serveur,$user,$pw,$bdd)
?>