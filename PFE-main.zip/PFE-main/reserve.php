
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reservations</title>
   
    <link rel="stylesheet" href="  https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link href="https://your-path-to-fontawesome/css/fontawesome.css" rel="stylesheet">
    <link href="https://your-path-to-fontawesome/css/brands.css" rel="stylesheet">
    <link href="https://your-path-to-fontawesome/css/solid.css" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.bundle.min.js">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css">
    <link href="  https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/boxicons@latest/css/boxicons.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js">


<style>
body {
    background-color: #000
}

.card-1 {
    border: none;
    border-radius: 10px;
    width: 100%;
    background-color: #fff;
    text-align: center;
}

.icons i {
    margin-left: 20px
}
</style>
</head>
<body>
    

<div class="container mt-5 d-flex justify-content-center">
    <div>
    <table class="table table-borderless table-responsive card-1 p-4">
        <thead>
            <tr class="border-bottom">
                <th> <span class="ml-2">Time</span> </th>
                <th> <span class="ml-2">client</span> </th>
                <th> <span class="ml-2">Barber</span> </th>
                <th> <span class="ml-2">Phone</span> </th>
                <th> <span class="ml-4">Action</span> </th>
            </tr>
        </thead>
        <tbody>
            <tr class="border-bottom">
                <td>
                    <div class="p-2"> <span class="d-block font-weight-bold">Tomorrow</span> <small>2:30PM</small> </div>
                </td>
                <td>
                    <div class="p-2 d-flex flex-row align-items-center mb-2"> <img src="https://i.imgur.com/ZSkeqnd.jpg" width="40" class="rounded-circle">
                        <div class="d-flex flex-column ml-2"> <span class="d-block font-weight-bold">Jennifer john</span> <small class="text-muted">Jasmine Owner Reality group</small> </div>
                    </div>
                </td>
                <td>
                    <div class="p-2"> <span class="font-weight-bold">Ammy Song</span> </div>
                </td>
                <td>
                    <div class="p-2 d-flex flex-column"> <span>+212 60000000</span> </div>
                </td>
                <td>
                    <div class="p-2 icons"> <i class="fa fa-phone text-warning"></i> <i class="fa fa-trash text-danger"></i>  </div>
                </td>
            </tr>
            <tr class="border-bottom">
                <td>
                    <div class="p-2"> <span class="d-block font-weight-bold">Tomorrow</span> <small>3:30PM</small> </div>
                </td>
                <td>
                    <div class="p-2 d-flex flex-row align-items-center mb-2"> <img src="https://i.imgur.com/C4egmYM.jpg" class="rounded-circle" width="40">
                        <div class="d-flex flex-column ml-2"> <span class="d-block font-weight-bold">David Smith</span> <small class="text-muted">Jasmine Owner Reality group</small> </div>
                    </div>
                </td>
                <td>
                    <div class="p-2"> <span class="font-weight-bold">David Clark</span> </div>
                </td>
                <td>
                    <div class="p-2 d-flex flex-column"> <span>+212 60000000</span> </div>
                </td>
                <td>
                    <div class="p-2 icons"> <i class="fa fa-phone text-warning"></i> <i class="fa fa-trash text-danger"></i>  </div>
                </td>
            </tr>
            <tr class="border-bottom">
                <td>
                    <div class="p-2"> <span class="d-block font-weight-bold">Tomorrow</span> <small>12:30PM</small> </div>
                </td>
                <td>
                    <div class="p-2 d-flex flex-row align-items-center mb-2"> <img src="https://i.imgur.com/0LKZQYM.jpg" class="rounded-circle" width="40">
                        <div class="d-flex flex-column ml-2"> <span class="d-block font-weight-bold">Emmily johnson</span> <small class="text-muted">Jasmine Owner Reality group</small> </div>
                    </div>
                </td>
                <td>
                    <div class="p-2"> <span class="font-weight-bold">Mary Kingston</span> </div>
                </td>
                <td>
                    <div class="p-2 d-flex flex-column"> <span>+212 60000000</span> </div>
                </td>
                <td>
                    <div class="p-2 icons"> <i class="fa fa-phone text-warning"></i> <i class="fa fa-trash text-danger"></i>  </div>
                </td>
            </tr>
            <tr class="border-bottom">
                <td>
                    <div class="p-2"> <span class="d-block font-weight-bold">Tomorrow</span> <small>1:30PM</small> </div>
                </td>
                <td>
                    <div class="p-2 d-flex flex-row align-items-center mb-2"> <img src="https://i.imgur.com/hczKIze.jpg" width="40" class="rounded-circle">
                        <div class="d-flex flex-column ml-2"> <span class="d-block font-weight-bold">Nick Jones</span> <small class="text-muted">Jasmine Owner Reality group</small> </div>
                    </div>
                </td>
                <td>
                    <div class="p-2"> <span class="font-weight-bold">James Smith</span> </div>
                </td>
                <td>
                    <div class="p-2 d-flex flex-column"> <span>+212 60000000</span> </div>
                </td>
                <td>
                    <div class="p-2 icons"> <i class="fa fa-phone text-warning"></i> <i class="fa fa-trash text-danger"></i>  </div>
                </td>
            </tr>
        </tbody>
    </table>
    </div>
</div>
</div>
</body>
</html>